//3D cube out of triangles
//Add rotating feature to the cube
//JavaScript Listeners
//Maybe add pulsation effect

var gl;
var canvas;

var verticesA = [];
var colorsA = [];

var verticesF = [];
var colorsF = [];

var theta;

class Drawable
{
    constructor(vertices, colors, program) {
        this.program = program;
        this.vBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.vBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, flatten(vertices), gl.STATIC_DRAW); // SET THE DATA, SPECIFY THE ARRAY, vertices in this cas

        this.cBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.cBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW);

        this.vAttributeLocation = gl.getAttribLocation(program, 'vPosition');
        this.cAttributeLocation = gl.getAttribLocation(program, 'vColor');
        this.translationLocation = gl.getUniformLocation(program, 'translation');
        this.scaleLocation = gl.getUniformLocation(program, 'scale');
        this.vertices = vertices;
        this.translation = vec3(0, 0, 0);
        this.scale = vec3(1, 1, 1);
    }

    draw()
    {
        gl.bindBuffer(gl.ARRAY_BUFFER, this.vBuffer);
        gl.vertexAttribPointer(this.vAttributeLocation, 3, gl.FLOAT, false, 0, 0); // DESCRIBE THE DATA: EACH vertex has 3 values of type FLOAT
        gl.enableVertexAttribArray(this.vAttributeLocation);

        gl.bindBuffer(gl.ARRAY_BUFFER, this.cBuffer);
        gl.vertexAttribPointer(this.cAttributeLocation, 4, gl.FLOAT, false, 0, 0); // DESCRIBE THE DATA: EACH vertex has 4 values of type FLOAT
        gl.enableVertexAttribArray(this.cAttributeLocation);

        console.log(this.translationLocation);
        gl.uniform3fv(this.translationLocation, this.translation);
        gl.uniform3fv(this.scaleLocation, this.scale);
        gl.drawArrays(gl.TRIANGLES, 0, this.vertices.length);
    }

    setTranslation(x, y, z)
    {
        this.translation = vec3(x, y, z);
    }
    setScale(x, y, z)
    {
        this.scale = vec3(x, y, z);
    }
}

var to_draw = [];

function init() {
    canvas = document.getElementById("gl-canvas");

    gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { alert("WebGL isn't available"); }

    gl.enable(gl.DEPTH_TEST);

    //CUBE 
    verticesA = [
        // SIDES
        vec3(0.1, 0.5, -0.2), //3
        vec3(0.5, -0.5, -0.2), //4 // TRIANGLE 9
        vec3(0.5, -0.5, 0.2), //8

        vec3(0.1, 0.5, -0.2), //3
        vec3(0.1, 0.5, 0.2), //6 // TRIANGLE 10
        vec3(0.5, -0.5, 0.2), //8

        vec3(-0.5, -0.5, -0.2), //1 Triangle 11
        vec3(-0.1, 0.5, -0.2), //2
        vec3(-0.1, 0.5, 0.2), //5

        vec3(-0.5, -0.5, -0.2), //1 Triangle 12
        vec3(-0.1, 0.5, 0.2), //5
        vec3(-0.5, -0.5, 0.2), //7 

        //TOP
        vec3(-0.1, 0.8, -0.2), //2
        vec3(-0.1, 0.8, 0.2), //5
        vec3(0.1, 0.8, -0.2), //3

        vec3(-0.1, 0.8, 0.2), //5
        vec3(0.1, 0.8, -0.2), //3
        vec3(0.1, 0.8, 0.2), //6

        //LEG 1
        vec3(-0.7, -0.7, -0.2), //1
        vec3(-0.7, -0.7, 0.2), //7
        vec3(-0.45, -0.7, -0.2), //9

        vec3(-0.7, -0.7, 0.2), //7
        vec3(-0.45, -0.7, -0.2), //9
        vec3(-0.45, -0.7, 0.2), // 16

        //INSIDE 
        vec3(-0.25, -0.5, -0.2), //9
        vec3(-0.25, -0.5, 0.2), // 16
        vec3(-0.10, -0.1, 0.2), // 12

        vec3(-0.25, -0.5, -0.2), //9
        vec3(-0.10, -0.1, 0.2), // 12
        vec3(-0.10, -0.1, -0.2), // 11

        vec3(-0.10, -0.1, 0.2), // 12
        vec3(-0.10, -0.1, -0.2), // 11
        vec3(0.10, -0.1, -0.2), // 14

        vec3(0.10, -0.1, -0.2), // 14
        vec3(-0.10, -0.1, 0.2), // 12
        vec3(0.10, -0.1, 0.2), // 13

        //----1----
        vec3(0.25, -0.5, -0.2), //20
        vec3(0.25, -0.5, 0.2), // 19
        vec3(0.10, -0.1, 0.2), // 13

        vec3(0.25, -0.5, -0.2), //20
        vec3(0.10, -0.1, 0.2), // 13
        vec3(0.10, -0.1, -0.2), // 14

        //-----2----

        vec3(0.5, -0.5, -0.2), //8
        vec3(0.5, -0.5, 0.2), //4
        vec3(0.25, -0.5, -0.2), //20

        vec3(0.5, -0.5, 0.2), //4
        vec3(0.25, -0.5, -0.2), //20
        vec3(0.25, -0.5, 0.2), // 19


        // hole podea

        vec3(-0.09, 0.05, 0.2), // A
        vec3(-0.09, 0.05, -0.2), // E
        vec3(0.09, 0.05, -0.2), // F

        vec3(0.09, 0.05, -0.2), // F
        vec3(-0.09, 0.05, 0.2), // A
        vec3(0.09, 0.05, 0.2), // B

        // hole pod

        vec3(-0.04, 0.3, 0.2), // D
        vec3(-0.04, 0.3, -0.2), // G
        vec3(0.04, 0.3, -0.2), // H

        vec3(0.04, 0.3, -0.2), // H
        vec3(-0.04, 0.3, 0.2), // D
        vec3(0.04, 0.3, 0.2), // C


        //hole stinga

        vec3(-0.04, 0.3, 0.2), // D
        vec3(-0.04, 0.3, -0.2), // G
        vec3(-0.09, 0.05, 0.2), // A

        vec3(-0.09, 0.05, 0.2), // A
        vec3(-0.09, 0.05, -0.2), // E
        vec3(-0.04, 0.3, -0.2), // G

        //hole dreapta

        vec3(0.04, 0.3, 0.2), // C
        vec3(0.04, 0.3, -0.2), // H
        vec3(0.09, 0.05, 0.2), // B

        vec3(0.09, 0.05, 0.2), // B
        vec3(0.09, 0.05, -0.2), // F
        vec3(0.04, 0.3, -0.2), // H

        //Coffin -x
        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.10, -0.1, -0.2), // 11 //1
        vec3(-0.25, -0.5, -0.2), //9

        vec3(-0.5, -0.5, 0.2), //1
        vec3(-0.10, -0.1, 0.2), // 11 //-1
        vec3(-0.25, -0.5, 0.2), //9

        vec3(-0.5, -0.5, 0.2), //1
        vec3(-0.10, -0.1, 0.2), // 11 //2
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.10, -0.1, -0.2), // 11 //-2
        vec3(-0.1, 0.5, -0.2), //2

        vec3(-0.10, -0.1, 0.2), // 11
        vec3(-0.09, 0.05, 0.2), // A // 3
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.10, -0.1, -0.2), // 11
        vec3(-0.09, 0.05, -0.2), // A // -3
        vec3(-0.1, 0.5, -0.2), //2

        vec3(-0.09, 0.05, 0.2), // A
        vec3(-0.04, 0.3, 0.2), // D // 4
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.09, 0.05, -0.2), // A
        vec3(-0.04, 0.3, -0.2), // D // 4
        vec3(-0.1, 0.5, -0.2), //2

        //Coffin -x
        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.10, -0.1, -0.2), // 11 //1
        vec3(-0.25, -0.5, -0.2), //9

        vec3(-0.5, -0.5, 0.2), //1
        vec3(-0.10, -0.1, 0.2), // 11 //-1
        vec3(-0.25, -0.5, 0.2), //9

        vec3(-0.5, -0.5, 0.2), //1
        vec3(-0.10, -0.1, 0.2), // 11 //2
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.10, -0.1, -0.2), // 11 //-2
        vec3(-0.1, 0.5, -0.2), //2

        vec3(-0.10, -0.1, 0.2), // 11
        vec3(-0.09, 0.05, 0.2), // A // 3
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.10, -0.1, -0.2), // 11
        vec3(-0.09, 0.05, -0.2), // A // -3
        vec3(-0.1, 0.5, -0.2), //2

        vec3(-0.09, 0.05, 0.2), // A
        vec3(-0.04, 0.3, 0.2), // D // 4
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.09, 0.05, -0.2), // A
        vec3(-0.04, 0.3, -0.2), // D // 4
        vec3(-0.1, 0.5, -0.2), //2

        //Coffin -x
        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.10, -0.1, -0.2), // 11 //1
        vec3(-0.25, -0.5, -0.2), //9

        vec3(-0.5, -0.5, 0.2), //1
        vec3(-0.10, -0.1, 0.2), // 11 //-1
        vec3(-0.25, -0.5, 0.2), //9

        vec3(-0.5, -0.5, 0.2), //1
        vec3(-0.10, -0.1, 0.2), // 11 //2
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.10, -0.1, -0.2), // 11 //-2
        vec3(-0.1, 0.5, -0.2), //2

        vec3(-0.10, -0.1, 0.2), // 11
        vec3(-0.09, 0.05, 0.2), // A // 3
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.10, -0.1, -0.2), // 11
        vec3(-0.09, 0.05, -0.2), // A // -3
        vec3(-0.1, 0.5, -0.2), //2

        vec3(-0.09, 0.05, 0.2), // A
        vec3(-0.04, 0.3, 0.2), // D // 4
        vec3(-0.1, 0.5, 0.2), //2

        vec3(-0.09, 0.05, -0.2), // A
        vec3(-0.04, 0.3, -0.2), // D // 4
        vec3(-0.1, 0.5, -0.2), //2

        //Coffin x
        vec3(0.5, -0.5, -0.2), //1
        vec3(0.10, -0.1, -0.2), // 11 //1
        vec3(0.25, -0.5, -0.2), //9

        vec3(0.5, -0.5, 0.2), //1
        vec3(0.10, -0.1, 0.2), // 11 //-1
        vec3(0.25, -0.5, 0.2), //9

        vec3(0.5, -0.5, 0.2), //1
        vec3(0.10, -0.1, 0.2), // 11 //2
        vec3(0.1, 0.5, 0.2), //2

        vec3(0.5, -0.5, -0.2), //1
        vec3(0.10, -0.1, -0.2), // 11 //-2
        vec3(0.1, 0.5, -0.2), //2

        vec3(0.10, -0.1, 0.2), // 11
        vec3(0.09, 0.05, 0.2), // A // 3
        vec3(0.1, 0.5, 0.2), //2

        vec3(0.10, -0.1, -0.2), // 11
        vec3(0.09, 0.05, -0.2), // A // -3
        vec3(0.1, 0.5, -0.2), //2

        vec3(0.09, 0.05, 0.2), // A
        vec3(0.04, 0.3, 0.2), // D // 4
        vec3(0.1, 0.5, 0.2), //2

        vec3(0.09, 0.05, -0.2), // A
        vec3(0.04, 0.3, -0.2), // D // 4
        vec3(0.1, 0.5, -0.2), //2

        vec3(-0.09, 0.05, 0.2), // A 
        vec3(0.09, 0.05, 0.2), // B
        vec3(-0.10, -0.1, 0.2), // 11

        vec3(0.10, -0.1, 0.2), // 13
        vec3(0.09, 0.05, 0.2), // B
        vec3(-0.10, -0.1, 0.2), // 11

        vec3(-0.04, 0.3, 0.2), // D
        vec3(0.04, 0.3, 0.2), // C
        vec3(-0.1, 0.5, 0.2), //2

        vec3(0.04, 0.3, 0.2), // C
        vec3(-0.1, 0.5, 0.2), //2
        vec3(0.1, 0.5, 0.2), //3

        vec3(-0.04, 0.3, -0.2), // D
        vec3(0.04, 0.3, -0.2), // C
        vec3(-0.1, 0.5, -0.2), //2

        vec3(0.04, 0.3, -0.2), // C
        vec3(-0.1, 0.5, -0.2), //2
        vec3(0.1, 0.5, -0.2), //3

        vec3(-0.09, 0.05, -0.2), // A 
        vec3(0.09, 0.05, -0.2), // B
        vec3(-0.10, -0.1, -0.2), // 11

        vec3(0.10, -0.1, -0.2), // 13
        vec3(0.09, 0.05, -0.2), // B
        vec3(-0.10, -0.1, -0.2), // 11

    ];

    black = vec4(0.0, 0.0, 0.0, 0.9);
    white = vec4(1.0, 0.0, 0.5, 0.9);

    colorsA = [
        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,
        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,


        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,



    ];

    //F
    verticesF = [

        vec3(-0.5, 0.5, -0.2), //2
        vec3(0.3, 0.5, -0.2), //3 // TRIANGLE 3
        vec3(-0.5, 0.5, 0.2), //5 

        vec3(0.3, 0.5, -0.2), //3 // TRIANGLE 4
        vec3(-0.5, 0.5, 0.2), //5
        vec3(0.3, 0.5, 0.2), //6

        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.2, -0.5, -0.2), //4
        vec3(-0.2, -0.5, 0.2), //8 // TRIANGLE 7

        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.5, -0.5, 0.2), //7 Triangle 8
        vec3(-0.2, -0.5, 0.2), //8

        vec3(-0.5, -0.5, -0.2), //1 Triangle 11
        vec3(-0.5, 0.5, -0.2), //2
        vec3(-0.5, 0.5, 0.2), //5

        vec3(-0.5, -0.5, -0.2), //1 Triangle 12
        vec3(-0.5, 0.5, 0.2), //5
        vec3(-0.5, -0.5, 0.2), //7 

        vec3(-0.2, -0.1, 0.2), //B
        vec3(-0.2, -0.1, -0.2), //A
        vec3(-0.2, -0.5, 0.2), //8

        vec3(-0.2, -0.5, -0.2), //4
        vec3(-0.2, -0.1, -0.2), //A
        vec3(-0.2, -0.5, 0.2), //8

        vec3(-0.2, -0.1, 0.2), //B
        vec3(-0.2, -0.1, -0.2), //A
        vec3(0.0, -0.1, -0.2), //C

        vec3(0.0, -0.1, -0.2), //C
        vec3(-0.2, -0.1, 0.2), //B
        vec3(0.0, -0.1, 0.2), //D

        vec3(0.0, -0.1, 0.2), //D
        vec3(0.0, -0.1, -0.2), //C
        vec3(0.0, 0.1, 0.2), //F

        vec3(0.0, -0.1, -0.2), //C
        vec3(0.0, 0.1, 0.2), //F
        vec3(0.0, 0.1, -0.2), //E

        vec3(-0.2, 0.1, 0.2), //H
        vec3(-0.2, 0.1, -0.2), //G
        vec3(0.0, 0.1, -0.2), //C

        vec3(0.0, 0.1, -0.2), //C
        vec3(-0.2, 0.1, 0.2), //H
        vec3(0.0, 0.1, 0.2), //D

        vec3(-0.2, 0.1, 0.2), //H
        vec3(-0.2, 0.1, -0.2), //G
        vec3(-0.2, 0.25, 0.2), // J

        vec3(-0.2, 0.1, -0.2), //G
        vec3(-0.2, 0.25, 0.2), // J
        vec3(-0.2, 0.25, -0.2), // I

        vec3(-0.2, 0.25, 0.2), // J
        vec3(-0.2, 0.25, -0.2), // I
        vec3(0.3, 0.25, -0.2), // K

        vec3(-0.2, 0.25, 0.2), // J
        vec3(0.3, 0.25, -0.2), // K
        vec3(0.3, 0.25, 0.2), // L

        vec3(0.3, 0.25, -0.2), // K
        vec3(0.3, 0.25, 0.2), // L
        vec3(0.3, 0.5, -0.2), // 3

        vec3(0.3, 0.5, 0.2), //6
        vec3(0.3, 0.5, -0.2), // 3
        vec3(0.3, 0.25, 0.2), // L   

        //CAPACELE
        vec3(0.3, 0.5, -0.2), // 3
        vec3(-0.5, 0.5, -0.2), //2
        vec3(-0.2, 0.25, -0.2), // I

        vec3(0.3, 0.5, -0.2), // 3
        vec3(0.3, 0.25, -0.2), // K
        vec3(-0.2, 0.25, -0.2), // I

        vec3(-0.5, 0.5, -0.2), //2
        vec3(-0.2, 0.25, -0.2), // I
        vec3(-0.2, 0.1, -0.2), //G

        vec3(-0.2, 0.1, -0.2), //G
        vec3(-0.5, 0.5, -0.2), //2
        vec3(-0.5, -0.5, -0.2), //1

        vec3(-0.5, -0.5, -0.2), //1
        vec3(-0.2, 0.1, -0.2), //G
        vec3(-0.2, -0.5, -0.2), //4

        vec3(-0.2, -0.1, -0.2), //A
        vec3(-0.2, 0.1, -0.2), //G
        vec3(0.0, 0.1, -0.2), //E

        vec3(-0.2, -0.1, -0.2), //A
        vec3(0.0, 0.1, -0.2), //C
        vec3(0.0, -0.1, -0.2), //E

        //CAPACELE 2 
        vec3(0.3, 0.5, 0.2), // 3
        vec3(-0.5, 0.5, 0.2), //2
        vec3(-0.2, 0.25, 0.2), // I

        vec3(0.3, 0.5, 0.2), // 3
        vec3(0.3, 0.25, 0.2), // K
        vec3(-0.2, 0.25, 0.2), // I

        vec3(-0.5, 0.5, 0.2), //2
        vec3(-0.2, 0.25, 0.2), // I
        vec3(-0.2, 0.1, 0.2), //G

        vec3(-0.2, 0.1, 0.2), //G
        vec3(-0.5, 0.5, 0.2), //2
        vec3(-0.5, -0.5, 0.2), //1

        vec3(-0.5, -0.5, 0.2), //1
        vec3(-0.2, 0.1, 0.2), //G
        vec3(-0.2, -0.5, 0.2), //4

        vec3(-0.2, -0.1, 0.2), //A
        vec3(-0.2, 0.1, 0.2), //G
        vec3(0.0, 0.1, 0.2), //E

        vec3(-0.2, -0.1, 0.2), //A
        vec3(0.0, 0.1, 0.2), //C
        vec3(0.0, -0.1, 0.2), //E

    ];

    black = vec4(0.0, 0.0, 0.0, 0.9);
    white = vec4(1.0, 1.0, 1.0, 0.9);

    colorsF = [
        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,


        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        black,
        black,
        black,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

        white,
        white,
        white,

    ];

    //
    //  Configure WebGL
    //
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(0.0, 0.2, 0.7, 0.4);

    //  Load shaders and initialize attribute buffers

    var program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    // Load the data into the GPU
    var A = new Drawable(verticesA, colorsA, program);
    A.setTranslation(0, 0, 0);
    A.setScale(0.7, 0.7, 0.7);

    var F = new Drawable(verticesF, colorsF, program)
    F.setTranslation(-0.4, 0, 0);
    F.setScale(0.7, 0.7, 0.7);

    var F2 = new Drawable(verticesF, colorsF, program)
    F2.setTranslation(0.4, 0, 0);
    F2.setScale(-0.7, 0.7, 0.7);

    to_draw.push(A);
    to_draw.push(F);
    to_draw.push(F2);
    
    render();
};

window.onload = init;

function render() {
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    to_draw.forEach(drawable => {
        drawable.draw();
    });
    // requestAnimFrame(render);
}